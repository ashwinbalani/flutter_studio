import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';

class UIData {
  //routes

  //fonts
  static const String quickFont = "Quicksand";
  static const String ralewayFont = "Raleway";
  static const String quickBoldFont = "Quicksand_Bold.otf";
  static const String quickNormalFont = "Quicksand_Book.otf";
  static const String quickLightFont = "Quicksand_Light.otf";

  //images
  static const String imageDir = "assets/images";

  //login
  static const String enter_code_label = "Phone Number";
  static const String enter_code_hint = "10 Digit Phone Number";
  static const String enter_otp_label = "OTP";
  static const String enter_otp_hint = "4 Digit OTP";
  static const String get_otp = "Get OTP";
  static const String resend_otp = "Resend OTP";
  static const String login = "Login";
  static const String enter_valid_number = "Enter 10 digit phone number";
  static const String enter_valid_otp = "Enter 4 digit otp";

  //gneric
  static const String error = "Error";
  static const String success = "Success";
  static const String ok = "OK";
  static const String forgot_password = "Forgot Password?";
  static const String something_went_wrong = "Something went wrong";
  static const String coming_soon = "Coming Soon";

  static const MaterialColor ui_kit_color = Colors.grey;

//colors
  static List<Color> kitGradients = [
    // new Color.fromRGBO(103, 218, 255, 1.0),
    // new Color.fromRGBO(3, 169, 244, 1.0),
    // new Color.fromRGBO(0, 122, 193, 1.0),
    Colors.blueGrey.shade800,
    Colors.black87,
  ];
  static List<Color> kitGradients2 = [
    Colors.cyan.shade600,
    Colors.blue.shade900
  ];

  //randomcolor
  static final Random _random = new Random();

  static const Color primaryColor = Color(0xff5555ff);
  static const Color secondaryColor = Color(0xffeeeeee);

  static final double FONT_SIZE_HEADING = 20;
  static final double FONT_SIZE_HEADING_XL = FONT_SIZE_HEADING+4;
  static final double FONT_SIZE_SUB_HEADING = FONT_SIZE_HEADING-4;
  static final double FONT_SIZE_ITEM = FONT_SIZE_HEADING-2;
  static final double FONT_SIZE_SUB_ITEM = FONT_SIZE_HEADING-6;
  static final double FONT_SIZE_BUTTON_TEXT = FONT_SIZE_HEADING-4;
  static final double FONT_SIZE_INFO_TEXT = FONT_SIZE_HEADING-8;
  static final double FONT_SIZE_CART_COST = FONT_SIZE_HEADING-4;

  /// Returns a random color.
  static Color next() {
    return new Color(0xFF000000 + _random.nextInt(0x00FFFFFF));
  }
}
