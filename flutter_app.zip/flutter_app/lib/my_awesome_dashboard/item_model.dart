import '../json_classes/purchase.dart';
import '../json_classes/customers.dart';
import '../json_classes/products.dart';
import '../json_classes/purchase.dart';
import 'dart:ui';

import '../constants.dart';

class ItemModel {
  final int id;
  final String title;
  final String subTitle;
  final String description;
  final String imageUrl;
  final bool isImageFromAsset;
  final Color backgroundColor;
  final List<ItemModel> lstOtherItems; //For a sub-list inside this list
  num numericData = 0;

  ItemModel(
      {this.id,
      this.title,
      this.subTitle,
      this.description,
      this.imageUrl,
      this.isImageFromAsset,
      this.lstOtherItems,
      this.backgroundColor = primaryColor,
      this.numericData});
}
