import '../json_classes/purchase.dart';
import '../json_classes/customers.dart';
import '../json_classes/products.dart';
import '../json_classes/purchase.dart';

import '../constants.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:rflutter_alert/rflutter_alert.dart';
import '../server_operations.dart';
import '../uidata.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:pie_chart/pie_chart.dart';

import 'constant.dart';
import 'counter.dart';
import 'item_model.dart';
import 'my_header.dart';

class SimpleValues extends StatefulWidget {
  String title ='My Dashboard';//"Dashboard title";
  bool isImageFromAssets = true;
  String imagePath ='assets/calendar.png';//"assets/doctor1.png";
  String caption ='ECommerce';//"Caption on the dashboard";
  String graphTitle ='Purchase dates';//"Graph title";

  @override
  _SimpleValuesState createState() => _SimpleValuesState();
}

class _SimpleValuesState extends State<SimpleValues> {
  final controller = ScrollController();
  double offset = 0;
  Map<String, double> dataMap = null; //dataMap.putIfAbsent("Flutter", () => 5);

  ItemModel metric1;
  ItemModel metric2;
  ItemModel metric3;
  List<double> lstGraphData;

  Future<Widget> getPieGraphData() async {
		var response = await http.post(SERVER_OPERATIONS,
        body: {'operation': OPERATION_FETCH_ALL_TBLPURCHASE});
    var body = response.body;
    try {
      var decodedJson = jsonDecode(body);
      Purchase jsonObject = Purchase.fromJson(decodedJson);
      setState(() {
        lstGraphData = List<double>();
        dataMap = Map<String, double>();
        for (int count = 0; count < jsonObject.Items.length; count++) {
          Purchase_items item = jsonObject.Items[count];
          lstGraphData.add(item.purchaseDate.toDouble());
          dataMap.putIfAbsent("${count+1}", () => item.purchaseDate.toDouble());
        }
      });
    } catch (ex) {
      print(ex.toString());
      setState(() {
        lstGraphData = null;
      });
    }

  }

  void getMetric1Data() async {
		var response = await http.post(SERVER_OPERATIONS,
        body: {'operation': OPERATION_FETCH_TOTAL_TBLCUSTOMERS});
    var body = response.body;
    try {
      var decodedJson = jsonDecode(body);

      String title = decodedJson['_items']['field_title'];
      int total = decodedJson['_items']['total'];
      metric1 = ItemModel(
          title: title,
          numericData: total
      );
    } catch (ex) {
      print(ex.toString());
      setState(() {
        metric1 = null;
      });
    }

  }

  void getMetric2Data() async {
		var response = await http.post(SERVER_OPERATIONS,
        body: {'operation': OPERATION_FETCH_TOTAL_TBLPRODUCTS});
    var body = response.body;
    try {
      var decodedJson = jsonDecode(body);

      String title = decodedJson['_items']['field_title'];
      int total = decodedJson['_items']['total'];
      metric2 = ItemModel(
          title: title,
          numericData: total
      );
    } catch (ex) {
      print(ex.toString());
      setState(() {
        metric2 = null;
      });
    }

  }

  void getMetric3Data() async {
		var response = await http.post(SERVER_OPERATIONS,
        body: {'operation': OPERATION_FETCH_TOTAL_TBLPURCHASE});
    var body = response.body;
    try {
      var decodedJson = jsonDecode(body);

      String title = decodedJson['_items']['field_title'];
      int total = decodedJson['_items']['total'];
      metric3 = ItemModel(
          title: title,
          numericData: total
      );
    } catch (ex) {
      print(ex.toString());
      setState(() {
        metric3 = null;
      });
    }

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.addListener(onScroll);
    getMetric1Data();
    getMetric2Data();
    getMetric3Data();
    getPieGraphData();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller.dispose();
    super.dispose();
  }

  void onScroll() {
    setState(() {
      offset = (controller.hasClients) ? controller.offset : 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    var date = new DateTime.now().toString();
    var dateParse = DateTime.parse(date);
    var formattedDate = "${dateParse.day}-${dateParse.month}-${dateParse.year}";

    return Scaffold(
      body: SingleChildScrollView(
        controller: controller,
        child: Column(
          children: <Widget>[
            MyHeader(
              image: widget.imagePath,
              isImageFromAsset: widget.isImageFromAssets,
              textTop: widget.title,
              textBottom: widget.caption,
              offset: offset,
            ),
            SizedBox(height: 20),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: widget.title + "\n",
                              style: kTitleTextstyle,
                            ),
                            TextSpan(
                              text: "Newest update:" + formattedDate.toString(),
                              style: TextStyle(
                                color: kTextLightColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          offset: Offset(0, 4),
                          blurRadius: 30,
                          color: kShadowColor,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Counter(
                          color: kInfectedColor,
                          number: ((metric1!=null)?metric1.numericData:0),
                          title: (metric1!=null)?metric1.title:"..."
                        ),
                        Counter(
                          color: kDeathColor,
                            number: ((metric2!=null)?metric2.numericData:0),
                            title: (metric2!=null)?metric2.title:"..."
                        ),
                        Counter(
                          color: kRecovercolor,
                            number: ((metric3!=null)?metric3.numericData:0),
                            title: (metric3!=null)?metric3.title:"..."
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        widget.graphTitle,
                        style: kTitleTextstyle,
                      ),
                      Text(
                        "See details",
                        style: TextStyle(
                          color: kPrimaryColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 178,
                    child: (dataMap!=null)?PieChart(
                      dataMap: dataMap,
                      showLegends: true,
                    ):LinearProgressIndicator(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
