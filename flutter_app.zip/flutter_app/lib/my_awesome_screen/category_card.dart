import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutterapp/my_awesome_screen/my_awesome_details_screen/stacked_display_with_options.dart';

import '../constants.dart';
import 'constants.dart';
import 'item_model.dart';

class CategoryCard extends StatelessWidget {
  final ItemModel itemModel;

  CategoryCard({this.itemModel});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 70.0,
      margin: EdgeInsets.only(left: 10.0),
      child: InkWell(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => StackedDisplayWithOptions(
                        itemModel: itemModel,
                      )));
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CircleAvatar(
              radius: 25.0,
              backgroundColor: itemModel.backgroundColor,
              child: (itemModel.isImageFromAsset)
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image(
                          height: 25.0,
                          width: 25.0,
                          fit: BoxFit.fill,
                          image: AssetImage(itemModel.imageUrl)),
                    )
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: CachedNetworkImage(
                        imageUrl: itemModel.imageUrl,
                        height: 25.0,
                        width: 25.0,
                        fit: BoxFit.fill,
                        placeholderFadeInDuration: Duration(milliseconds: 100),
                        placeholder: (context, url) => Container(
                          color: Color(0xffeeeeee),
                          child: Image.asset(loaderImagePath),
                        ),
                        errorWidget: (context, url, error) => Icon(Icons.error),
                      ),
                    ),
            ),
            Text(itemModel.title, style: kTitleItem),
            Text(
              "${itemModel.subTitle}",
              style: kSubtitleItem,
            ),
          ],
        ),
      ),
    );
  }
}
