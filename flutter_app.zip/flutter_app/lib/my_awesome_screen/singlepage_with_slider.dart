import '../json_classes/customers.dart';
import '../json_classes/products.dart';

import '../constants.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:rflutter_alert/rflutter_alert.dart';
import '../server_operations.dart';
import '../uidata.dart';
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';

import 'category_card.dart';
import 'constants.dart';
import 'custom_list_tile.dart';
import 'horizontal_card2.dart';
import 'item_model.dart';

class SinglePageWithSlider extends StatefulWidget {
  String title ='E Commerce';//"Page Title";
  String searchHint ='Search for phones';//"Search hint";
  String horizontalListText ='Customers';//"H Categories";
  String horizontalListText2 ='Products';//"H Categories 2";
  String itemDetailBackgroundImage ='assets/ux_big.png';//"https://image.freepik.com/free-photo/beautiful-autumn-leaves-autumn-red-background-sunny-daylight-horizontal_1220-1660.jpg";
  bool isAssetItemDetailBackgroundImage = true;

  static Function onSearch(BuildContext context, String text) {
    print("Searching for " + text);
  }

  @override
  _SinglePageWithSliderState createState() => _SinglePageWithSliderState();
}

class _SinglePageWithSliderState extends State<SinglePageWithSlider> {
  TextEditingController searchTextController = TextEditingController();

  List<ItemModel> lstHorizontalItems = null;
  List<ItemModel> lstHorizontalItems2 = null;

  void showMenuCalled() {
//CODE_REPLACE <SHOW_MENU_CALLED>
    print("Show Menu Called");
  }

  void showProfileCalled() {
//CODE_REPLACE <SHOW_PROFILE_CALLED>
    print("Show Profile Called");
  }

  Future<Widget> getHorizontalListData() async {
var response = await http.post(SERVER_OPERATIONS,
    body: {'operation': OPERATION_FETCH_ALL_TBLCUSTOMERS});
var body = response.body;
try {
  var decodedJson = jsonDecode(body);
  Customers jsonObject = Customers.fromJson(decodedJson);
  setState(() {
    lstHorizontalItems = List<ItemModel>();
    for (int count = 0; count < jsonObject.Items.length; count++) {
      Customers_items item = jsonObject.Items[count];
      ItemModel itemModel = ItemModel(
          id: item.id,
          title: item.name,
          imageUrl:item.profilePic,
          backgroundColor: primaryColor,
          description: item.address,
          subTitle: item.phone,
          isImageFromAsset: false,
          lstOtherItems: null);
      lstHorizontalItems.add(itemModel);
    }
  });
} catch (ex) {
  setState(() {
    lstHorizontalItems = null;
  });
}

  }

  Future<Widget> getHorizontalList2Data() async {
var response = await http.post(SERVER_OPERATIONS,
    body: {'operation': OPERATION_FETCH_ALL_TBLPRODUCTS});
var body = response.body;
try {
  var decodedJson = jsonDecode(body);
  Products jsonObject = Products.fromJson(decodedJson);
  setState(() {
    lstHorizontalItems2 = List<ItemModel>();
    for (int count = 0; count < jsonObject.Items.length; count++) {
      Products_items item = jsonObject.Items[count];
      ItemModel itemModel = ItemModel(
          id: item.id,
          title: item.name,
          imageUrl:item.imageUrl,
          backgroundColor: primaryColor,
          description: item.description,
          subTitle: item.weight,
          isImageFromAsset: false,
          lstOtherItems: null);
      lstHorizontalItems2.add(itemModel);
    }
  });
} catch (ex) {
  setState(() {
    lstHorizontalItems2 = null;
  });
}

  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getHorizontalListData();
    getHorizontalList2Data();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              ClipPath(
                clipper: OvalBottomBorderClipper(),
                child: Container(
                  width: double.infinity,
                  height: 250.0,
                  padding: EdgeInsets.only(bottom: 50.0),
                  decoration: BoxDecoration(
                    color: kYellow,
                    image: DecorationImage(
                      image: (widget.isAssetItemDetailBackgroundImage)
                          ? AssetImage(widget.itemDetailBackgroundImage)
                          : CachedNetworkImageProvider(
                              widget.itemDetailBackgroundImage),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppBar(
                        backgroundColor: Colors.black12.withOpacity(.0),
                        elevation: 0,
                        leading: InkWell(
                            onTap: () {
                              showMenuCalled();
                            },
                            child: Icon(Icons.menu)),
                        actions: [
                          IconButton(
                            icon: Icon(Icons.supervised_user_circle),
                            onPressed: () {
                              showProfileCalled();
                            },
                          )
                        ],
                      ),
                      Spacer(),
                      Padding(
                        padding: const EdgeInsets.only(left: 18.0),
                        child: Text(
                          widget.title,
                          style: kTitleStyle.copyWith(color: Colors.white),
                        ),
                      ),
                      SizedBox(height: 15.0),
                      Container(
                        width: double.infinity,
                        height: 50.0,
                        margin: EdgeInsets.symmetric(horizontal: 18.0),
                        padding: EdgeInsets.symmetric(horizontal: 15.0),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.0),
                          color: Colors.white.withOpacity(.9),
                        ),
                        child: TextField(
                          cursorColor: kBlack,
                          controller: searchTextController,
                          onSubmitted: (text) {
                            SinglePageWithSlider.onSearch(context, text);
                          },
                          decoration: InputDecoration(
                            hintText: widget.searchHint,
                            hintStyle: kHintStyle,
                            border: InputBorder.none,
                            icon: Icon(
                              Icons.search,
                              color: kGrey,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 25.0),
              CustomListTile(title: widget.horizontalListText),
              SizedBox(height: 25.0),
              Container(
                width: double.infinity,
                height: 100.0,
                child: (lstHorizontalItems != null)
                    ? ListView.builder(
                        itemCount: lstHorizontalItems.length,
                        scrollDirection: Axis.horizontal,
                        physics: ScrollPhysics(),
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          ItemModel itemModel = lstHorizontalItems[index];
                          return CategoryCard(itemModel: itemModel);
                        },
                      )
                    : LinearProgressIndicator(),
              ),
              SizedBox(height: 30.0),
              CustomListTile(title: widget.horizontalListText2),
              SizedBox(height: 25.0),
              Container(
                width: double.infinity,
                height: 150.0,
                child: (lstHorizontalItems2 != null)
                    ? ListView.builder(
                        itemCount: lstHorizontalItems2.length,
                        scrollDirection: Axis.horizontal,
                        physics: ScrollPhysics(),
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          ItemModel itemModel = lstHorizontalItems2[index];
                          return HorizontalCard2(itemModel: itemModel);
                        },
                      )
                    : LinearProgressIndicator(),
              ),
              SizedBox(height: 50.0),
            ],
          ),
        ),
      ),
    );
  }
}
