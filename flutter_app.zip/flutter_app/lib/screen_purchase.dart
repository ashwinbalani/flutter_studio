import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:file_picker/file_picker.dart';
import 'json_classes/purchase.dart';
import 'server_operations.dart';
import 'uidata.dart';

class ScreenPurchase extends StatefulWidget {
  ScreenPurchase();

  @override
  _ScreenPurchaseState createState() => _ScreenPurchaseState();
}

class _ScreenPurchaseState extends State<ScreenPurchase> {
  Purchase jsonObject;
  
  TextEditingController _controllercustomer_id = TextEditingController();
TextEditingController _controllerproduct_id = TextEditingController();
TextEditingController _controllerpurchase_date = TextEditingController();

  
  void getPurchase() async {
    var response = await http.post(SERVER_OPERATIONS, body: {
      'operation': OPERATION_FETCH_ALL_TBLPURCHASE
    });
    var body = response.body;
    try {
      var decodedJson = jsonDecode(body);

      setState(() {
        jsonObject = Purchase.fromJson(decodedJson);
      });
    } catch (ex) {
      setState(() {
        jsonObject = null;
      });
    }
  }
  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getPurchase();
  }

  void insertRecord() async {
		var postUri = Uri.parse(SERVER_OPERATIONS);
		var request = new http.MultipartRequest("POST", postUri);
		request.fields['operation'] = OPERATION_INSERT_INTO_TBLPURCHASE;
		request.fields['customer_id'] = _controllercustomer_id.text;
request.fields['product_id'] = _controllerproduct_id.text;
request.fields['purchase_date'] = _controllerpurchase_date.text;

		
    request.send().then((response) {
			response.stream.transform(utf8.decoder).listen((value) {
				var body = value;
				try {
					var decodedJson = jsonDecode(body);
					if (decodedJson['error'] == false) {
						Fluttertoast.showToast(
								msg: "Purchase" + " Added",
								toastLength: Toast.LENGTH_SHORT,
								gravity: ToastGravity.CENTER,
								timeInSecForIosWeb: 1,
								backgroundColor: UIData.primaryColor,
								textColor: Colors.white,
								fontSize: UIData.FONT_SIZE_HEADING
						);
						getPurchase();
					} else {
						Alert(
							style: AlertStyle(
								isCloseButton: false,
								alertBorder: RoundedRectangleBorder(
									borderRadius: BorderRadius.circular(16.0),
									side: BorderSide(
										color: Colors.grey,
									),
								),
							),
							context: context,
							type: AlertType.error,
							title: "Error",
							desc:
							"Unable to add record. Please check your network connection and try again.",
							buttons: [
								DialogButton(
									child: Text(
										"Ok",
										style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_HEADING),
									),
									onPressed: () =>
											Navigator.of(context, rootNavigator: true).pop(),
									color: UIData.primaryColor,
								),
							],
						).show();
					}
				} catch (ex) {
					print(body);
				}
			});
      
    });
  }

  void updateRecord(int recordId) async {
		var postUri = Uri.parse(SERVER_OPERATIONS);
		var request = new http.MultipartRequest("POST", postUri);
		request.fields['operation'] = OPERATION_UPDATE_TBLPURCHASE;
		request.fields['id'] = recordId.toString();
		request.fields['customer_id'] = _controllercustomer_id.text;
request.fields['product_id'] = _controllerproduct_id.text;
request.fields['purchase_date'] = _controllerpurchase_date.text;

		
    request.send().then((response) {
			response.stream.transform(utf8.decoder).listen((value) {
				var body = value;
				try {
					var decodedJson = jsonDecode(body);
					if (decodedJson['error'] == false) {
						Fluttertoast.showToast(
								msg: "Purchase" + " Updated",
								toastLength: Toast.LENGTH_SHORT,
								gravity: ToastGravity.CENTER,
								timeInSecForIosWeb: 1,
								backgroundColor: UIData.primaryColor,
								textColor: Colors.white,
								fontSize: UIData.FONT_SIZE_HEADING
						);
						getPurchase();
					} else {
						Alert(
							style: AlertStyle(
								isCloseButton: false,
								alertBorder: RoundedRectangleBorder(
									borderRadius: BorderRadius.circular(16.0),
									side: BorderSide(
										color: Colors.grey,
									),
								),
							),
							context: context,
							type: AlertType.error,
							title: "Error",
							desc:
							"Unable to update record. Please check your network connection and try again.",
							buttons: [
								DialogButton(
									child: Text(
										"Ok",
										style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_HEADING),
									),
									onPressed: () =>
											Navigator.of(context, rootNavigator: true).pop(),
									color: UIData.primaryColor,
								),
							],
						).show();
					}
				} catch (ex) {}
			});
    });
  }

  void deleteRecord(int recordId) {
    Alert(
      style: AlertStyle(
        isCloseButton: false,
        alertBorder: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
          side: BorderSide(
            color: Colors.grey,
          ),
        ),
      ),
      context: context,
      type: AlertType.warning,
      title: "Delete Record?",
      desc: "Are you sure you want to delete this record?",
      buttons: [
        DialogButton(
          child: Text(
            "No",
            style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
          ),
          onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
          color: Colors.grey,
        ),
        DialogButton(
          child: Text(
            "Yes",
            style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
          ),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop();
            performDelete(recordId);
          },
          color: UIData.primaryColor,
        )
      ],
    ).show();
  }

  void performDelete(int recordId) async {
    http.post(SERVER_OPERATIONS, body: {
      'operation': OPERATION_DELETE_FROM_TBLPURCHASE,
      'id': recordId.toString()
    }).then((var value) {

      var body = value.body;
      try {
        var decodedJson = jsonDecode(body);
        if (decodedJson['error'] == false) {
          Fluttertoast.showToast(
              msg: "Purchase" + " Deleted",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              timeInSecForIosWeb: 1,
              backgroundColor: UIData.primaryColor,
              textColor: Colors.red,
              fontSize: UIData.FONT_SIZE_HEADING
          );
          getPurchase();
        } else {
          throw Exception("Unable to delete");
        }
      } catch (ex) {
        Alert(
          style: AlertStyle(
            isCloseButton: false,
            alertBorder: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
              side: BorderSide(
                color: Colors.grey,
              ),
            ),
          ),
          context: context,
          type: AlertType.error,
          title: "Error",
          desc:
          "Unable to delete record, please check connection",
          buttons: [
            DialogButton(
              child: Text(
                "Ok",
                style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
              ),
              onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
              color: UIData.primaryColor,
            ),
          ],
        ).show();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final title = "Manage " + " Purchase";

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: title,
      home: Scaffold(
          floatingActionButton: FloatingActionButton(
            backgroundColor: UIData.primaryColor,
            foregroundColor: Colors.white,
            elevation: 2,
            child: Icon(Icons.add),
            onPressed: () {
              showInsertUpdateDeletDialog(-1);
            },
          ),
          floatingActionButtonLocation:
          FloatingActionButtonLocation.centerFloat,
          appBar: AppBar(
            title: Text(title),
            backgroundColor: UIData.primaryColor,
          ),
          body: jsonObject == null
              ? LinearProgressIndicator()
              : (jsonObject.Items.length == 0)
              ? Container(
              child: Align(
                alignment: Alignment.center,
                child: Text(
                    "No " + "Purchase" + " found\n\nTap on the + icon to add a record",
                    style: TextStyle(fontSize: UIData.FONT_SIZE_HEADING)),
              ))
              : Container(
              child: CustomScrollView(
                slivers: <Widget>[
                  SliverList(
                      delegate: jsonObject == null
                          ? SliverChildListDelegate(
                          [LinearProgressIndicator()])
                          : SliverChildBuilderDelegate(
                            (context, index) {
                          return InkWell(
                            onTap: () {},
                            child: Padding(
                              padding:
                              EdgeInsets.only(left: 4, top: 8),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: UIData.primaryColor,
                                  foregroundColor: Colors.white,
                                  child: Text(
                                      jsonObject
                                          .Items[index]
                                          .id.toString(),
                                      style:
                                      TextStyle(fontSize: UIData.FONT_SIZE_HEADING)),
                                ),
								title: Text(jsonObject.Items[index].id.toString()),
                                subtitle: Text(
                                    jsonObject.Items[index].customerId.toString(),
                                    style: TextStyle(fontSize: UIData.FONT_SIZE_SUB_HEADING)),
                                onTap: () {
                                  showInsertUpdateDeletDialog(index);
                                },
                              ),
                            ),
                          );
                        },
                        childCount:
                        jsonObject.Items.length,
                      ))
                ],
              ))),
    );
  }

  void showInsertUpdateDeletDialog(int index) {

    int id = -1;
    if(index >= 0) {
      //Update this record
      id = jsonObject.Items[index].id;
      
      num customer_id = jsonObject.Items[index].customerId;
num product_id = jsonObject.Items[index].productId;
num purchase_date = jsonObject.Items[index].purchaseDate;


      _controllercustomer_id.text = customer_id.toString();
_controllerproduct_id.text = product_id.toString();
_controllerpurchase_date.text = purchase_date.toString();

    } else {
      _controllercustomer_id.text = '';
_controllerproduct_id.text = '';
_controllerpurchase_date.text = '';

    }

    Alert(
        context: context,
        title: "Manage" + "Purchase",
        style: AlertStyle(
          isCloseButton: false,
          alertBorder: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
            side: BorderSide(
              color: Colors.grey,
            ),
          ),
        ),
        content: Column(
          children: <Widget>[
						TextField(
              controller: _controllercustomer_id,
              decoration: InputDecoration(
                icon: Icon(Icons.short_text),
                labelText: 'customer_id',
              ),
            ),
			TextField(
              controller: _controllerproduct_id,
              decoration: InputDecoration(
                icon: Icon(Icons.short_text),
                labelText: 'product_id',
              ),
            ),
			TextField(
              controller: _controllerpurchase_date,
              decoration: InputDecoration(
                icon: Icon(Icons.short_text),
                labelText: 'purchase_date',
              ),
            ),

          ],
        ),
        buttons: [
          DialogButton(
            child: Text(
              "Insert",
              style: TextStyle(color: Colors.black, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
            ),
            onPressed: () {
              //Send request to add this address
              insertRecord();
              Navigator.of(context, rootNavigator: true).pop();
            },
          ),
          (id==-1)?DialogButton():DialogButton(
            child: Text(
              "Update",
              style: TextStyle(color: Colors.green, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
            ),
            onPressed: () {
              //Send request to add this address
              updateRecord(id);
              Navigator.of(context, rootNavigator: true).pop();
            },
          ),
          (id==-1)?DialogButton():DialogButton(
            child: Text(
              "Delete",
              style: TextStyle(color: Colors.red, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
            ),
            onPressed: () {
              Navigator.of(context, rootNavigator: true).pop();
              deleteRecord(id);
            },
          )
        ]).show();
  }
}
