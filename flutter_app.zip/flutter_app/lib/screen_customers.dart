import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:file_picker/file_picker.dart';
import 'json_classes/customers.dart';
import 'server_operations.dart';
import 'uidata.dart';

class ScreenCustomers extends StatefulWidget {
  ScreenCustomers();

  @override
  _ScreenCustomersState createState() => _ScreenCustomersState();
}

class _ScreenCustomersState extends State<ScreenCustomers> {
  Customers jsonObject;
  
  TextEditingController _controllername = TextEditingController();
TextEditingController _controllerphone = TextEditingController();
TextEditingController _controlleraddress = TextEditingController();
File _fileprofile_pic;

  
  void getCustomers() async {
    var response = await http.post(SERVER_OPERATIONS, body: {
      'operation': OPERATION_FETCH_ALL_TBLCUSTOMERS
    });
    var body = response.body;
    try {
      var decodedJson = jsonDecode(body);

      setState(() {
        jsonObject = Customers.fromJson(decodedJson);
      });
    } catch (ex) {
      setState(() {
        jsonObject = null;
      });
    }
  }
  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCustomers();
  }

  void insertRecord() async {
		var postUri = Uri.parse(SERVER_OPERATIONS);
		var request = new http.MultipartRequest("POST", postUri);
		request.fields['operation'] = OPERATION_INSERT_INTO_TBLCUSTOMERS;
		request.fields['name'] = _controllername.text;
request.fields['phone'] = _controllerphone.text;
request.fields['address'] = _controlleraddress.text;
request.files.add(new http.MultipartFile.fromBytes('profile_pic', await _fileprofile_pic.readAsBytes(), filename: _fileprofile_pic.path));

		
    request.send().then((response) {
			response.stream.transform(utf8.decoder).listen((value) {
				var body = value;
				try {
					var decodedJson = jsonDecode(body);
					if (decodedJson['error'] == false) {
						Fluttertoast.showToast(
								msg: "Customers" + " Added",
								toastLength: Toast.LENGTH_SHORT,
								gravity: ToastGravity.CENTER,
								timeInSecForIosWeb: 1,
								backgroundColor: UIData.primaryColor,
								textColor: Colors.white,
								fontSize: UIData.FONT_SIZE_HEADING
						);
						getCustomers();
					} else {
						Alert(
							style: AlertStyle(
								isCloseButton: false,
								alertBorder: RoundedRectangleBorder(
									borderRadius: BorderRadius.circular(16.0),
									side: BorderSide(
										color: Colors.grey,
									),
								),
							),
							context: context,
							type: AlertType.error,
							title: "Error",
							desc:
							"Unable to add record. Please check your network connection and try again.",
							buttons: [
								DialogButton(
									child: Text(
										"Ok",
										style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_HEADING),
									),
									onPressed: () =>
											Navigator.of(context, rootNavigator: true).pop(),
									color: UIData.primaryColor,
								),
							],
						).show();
					}
				} catch (ex) {
					print(body);
				}
			});
      
    });
  }

  void updateRecord(int recordId) async {
		var postUri = Uri.parse(SERVER_OPERATIONS);
		var request = new http.MultipartRequest("POST", postUri);
		request.fields['operation'] = OPERATION_UPDATE_TBLCUSTOMERS;
		request.fields['id'] = recordId.toString();
		request.fields['name'] = _controllername.text;
request.fields['phone'] = _controllerphone.text;
request.fields['address'] = _controlleraddress.text;
request.files.add(new http.MultipartFile.fromBytes('profile_pic', await _fileprofile_pic.readAsBytes(), filename: _fileprofile_pic.path));

		
    request.send().then((response) {
			response.stream.transform(utf8.decoder).listen((value) {
				var body = value;
				try {
					var decodedJson = jsonDecode(body);
					if (decodedJson['error'] == false) {
						Fluttertoast.showToast(
								msg: "Customers" + " Updated",
								toastLength: Toast.LENGTH_SHORT,
								gravity: ToastGravity.CENTER,
								timeInSecForIosWeb: 1,
								backgroundColor: UIData.primaryColor,
								textColor: Colors.white,
								fontSize: UIData.FONT_SIZE_HEADING
						);
						getCustomers();
					} else {
						Alert(
							style: AlertStyle(
								isCloseButton: false,
								alertBorder: RoundedRectangleBorder(
									borderRadius: BorderRadius.circular(16.0),
									side: BorderSide(
										color: Colors.grey,
									),
								),
							),
							context: context,
							type: AlertType.error,
							title: "Error",
							desc:
							"Unable to update record. Please check your network connection and try again.",
							buttons: [
								DialogButton(
									child: Text(
										"Ok",
										style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_HEADING),
									),
									onPressed: () =>
											Navigator.of(context, rootNavigator: true).pop(),
									color: UIData.primaryColor,
								),
							],
						).show();
					}
				} catch (ex) {}
			});
    });
  }

  void deleteRecord(int recordId) {
    Alert(
      style: AlertStyle(
        isCloseButton: false,
        alertBorder: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.0),
          side: BorderSide(
            color: Colors.grey,
          ),
        ),
      ),
      context: context,
      type: AlertType.warning,
      title: "Delete Record?",
      desc: "Are you sure you want to delete this record?",
      buttons: [
        DialogButton(
          child: Text(
            "No",
            style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
          ),
          onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
          color: Colors.grey,
        ),
        DialogButton(
          child: Text(
            "Yes",
            style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
          ),
          onPressed: () {
            Navigator.of(context, rootNavigator: true).pop();
            performDelete(recordId);
          },
          color: UIData.primaryColor,
        )
      ],
    ).show();
  }

  void performDelete(int recordId) async {
    http.post(SERVER_OPERATIONS, body: {
      'operation': OPERATION_DELETE_FROM_TBLCUSTOMERS,
      'id': recordId.toString()
    }).then((var value) {

      var body = value.body;
      try {
        var decodedJson = jsonDecode(body);
        if (decodedJson['error'] == false) {
          Fluttertoast.showToast(
              msg: "Customers" + " Deleted",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              timeInSecForIosWeb: 1,
              backgroundColor: UIData.primaryColor,
              textColor: Colors.red,
              fontSize: UIData.FONT_SIZE_HEADING
          );
          getCustomers();
        } else {
          throw Exception("Unable to delete");
        }
      } catch (ex) {
        Alert(
          style: AlertStyle(
            isCloseButton: false,
            alertBorder: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
              side: BorderSide(
                color: Colors.grey,
              ),
            ),
          ),
          context: context,
          type: AlertType.error,
          title: "Error",
          desc:
          "Unable to delete record, please check connection",
          buttons: [
            DialogButton(
              child: Text(
                "Ok",
                style: TextStyle(color: Colors.white, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
              ),
              onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
              color: UIData.primaryColor,
            ),
          ],
        ).show();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final title = "Manage " + " Customers";

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: title,
      home: Scaffold(
          floatingActionButton: FloatingActionButton(
            backgroundColor: UIData.primaryColor,
            foregroundColor: Colors.white,
            elevation: 2,
            child: Icon(Icons.add),
            onPressed: () {
              showInsertUpdateDeletDialog(-1);
            },
          ),
          floatingActionButtonLocation:
          FloatingActionButtonLocation.centerFloat,
          appBar: AppBar(
            title: Text(title),
            backgroundColor: UIData.primaryColor,
          ),
          body: jsonObject == null
              ? LinearProgressIndicator()
              : (jsonObject.Items.length == 0)
              ? Container(
              child: Align(
                alignment: Alignment.center,
                child: Text(
                    "No " + "Customers" + " found\n\nTap on the + icon to add a record",
                    style: TextStyle(fontSize: UIData.FONT_SIZE_HEADING)),
              ))
              : Container(
              child: CustomScrollView(
                slivers: <Widget>[
                  SliverList(
                      delegate: jsonObject == null
                          ? SliverChildListDelegate(
                          [LinearProgressIndicator()])
                          : SliverChildBuilderDelegate(
                            (context, index) {
                          return InkWell(
                            onTap: () {},
                            child: Padding(
                              padding:
                              EdgeInsets.only(left: 4, top: 8),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: UIData.primaryColor,
                                  foregroundColor: Colors.white,
                                  child: Text(
                                      jsonObject
                                          .Items[index]
                                          .id.toString(),
                                      style:
                                      TextStyle(fontSize: UIData.FONT_SIZE_HEADING)),
                                ),
								title: Text(jsonObject.Items[index].name),
                                subtitle: Text(
                                    jsonObject.Items[index].phone,
                                    style: TextStyle(fontSize: UIData.FONT_SIZE_SUB_HEADING)),
                                onTap: () {
                                  showInsertUpdateDeletDialog(index);
                                },
                              ),
                            ),
                          );
                        },
                        childCount:
                        jsonObject.Items.length,
                      ))
                ],
              ))),
    );
  }

  void showInsertUpdateDeletDialog(int index) {

    int id = -1;
    if(index >= 0) {
      //Update this record
      id = jsonObject.Items[index].id;
      
      String name = jsonObject.Items[index].name;
String phone = jsonObject.Items[index].phone;
String address = jsonObject.Items[index].address;
String profile_pic = jsonObject.Items[index].profilePic;


      _controllername.text = name.toString();
_controllerphone.text = phone.toString();
_controlleraddress.text = address.toString();

    } else {
      _controllername.text = '';
_controllerphone.text = '';
_controlleraddress.text = '';

    }

    Alert(
        context: context,
        title: "Manage" + "Customers",
        style: AlertStyle(
          isCloseButton: false,
          alertBorder: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
            side: BorderSide(
              color: Colors.grey,
            ),
          ),
        ),
        content: Column(
          children: <Widget>[
						TextField(
              controller: _controllername,
              decoration: InputDecoration(
                icon: Icon(Icons.short_text),
                labelText: 'name',
              ),
            ),
			TextField(
              controller: _controllerphone,
              decoration: InputDecoration(
                icon: Icon(Icons.short_text),
                labelText: 'phone',
              ),
            ),
			TextField(
              controller: _controlleraddress,
              decoration: InputDecoration(
                icon: Icon(Icons.short_text),
                labelText: 'address',
              ),
            ),
			Align(
				alignment: Alignment.centerLeft,
				child: Padding(
					padding: EdgeInsets.all(10),
					child: ClipRRect(
						borderRadius: BorderRadius.circular(20),
						child: MaterialButton(
								color: UIData.primaryColor,
								minWidth: MediaQuery.of(context).size.width,
								child: new Text('Pick profile_pic',
										style: new TextStyle(fontSize: 16.0, color: Colors.white)),
										onPressed: () async {
											_fileprofile_pic = await FilePicker.getFile();
										}),
					),
				),
			),

          ],
        ),
        buttons: [
          DialogButton(
            child: Text(
              "Insert",
              style: TextStyle(color: Colors.black, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
            ),
            onPressed: () {
              //Send request to add this address
              insertRecord();
              Navigator.of(context, rootNavigator: true).pop();
            },
          ),
          (id==-1)?DialogButton():DialogButton(
            child: Text(
              "Update",
              style: TextStyle(color: Colors.green, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
            ),
            onPressed: () {
              //Send request to add this address
              updateRecord(id);
              Navigator.of(context, rootNavigator: true).pop();
            },
          ),
          (id==-1)?DialogButton():DialogButton(
            child: Text(
              "Delete",
              style: TextStyle(color: Colors.red, fontSize: UIData.FONT_SIZE_BUTTON_TEXT),
            ),
            onPressed: () {
              Navigator.of(context, rootNavigator: true).pop();
              deleteRecord(id);
            },
          )
        ]).show();
  }
}
