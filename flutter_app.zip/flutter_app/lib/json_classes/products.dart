
class Products{
									  
bool  error;
num  errorCode;
List<Products_items>  Items;

									  
Products({this.error,
this.errorCode,
this.Items,});
									  

Products.fromJson(Map<String, dynamic> json) {
											 
error = json['error'];
errorCode = json['error_code'];

if (json['_items'] != null) {
												  
Items = new List<Products_items>();
												  
json['_items'].forEach((v) {
												  
Items.add(new Products_items.fromJson(v));
												  
});
												  
}

											 
}
									  

										   
Map<String, dynamic> toJson()=> _toJson();
								   
Map<String, dynamic> _toJson() {
										   
final Map<String, dynamic> data = new Map<String, dynamic>();
										   
 data['error'] = this.error._toJson();
 data['error_code'] = this.errorCode._toJson();

if (this.Items != null) {
												
data['_items'] = this.Items.map((v) => v._toJson())?.toList();
												
}

										   
return data;
										   
}
									  
}
									  

class Products_items{
									  
num  id;
String  name;
String  weight;
String  description;
num  price;
String  imageUrl;

									  
Products_items({this.id,
this.name,
this.weight,
this.description,
this.price,
this.imageUrl,
});
									  

Products_items.fromJson(Map<String, dynamic> json) {
											 
id = json['id'];
name = json['name'];
weight = json['weight'];
description = json['description'];
price = json['price'];
imageUrl = json['image_url'];

											 
}
									  

										   
Map<String, dynamic> toJson()=> _toJson();
								   
Map<String, dynamic> _toJson() {
										   
final Map<String, dynamic> data = new Map<String, dynamic>();
										   
 data['id'] = this.id._toJson();
 data['name'] = this.name._toJson();
 data['weight'] = this.weight._toJson();
 data['description'] = this.description._toJson();
 data['price'] = this.price._toJson();
 data['image_url'] = this.imageUrl._toJson();

										   
return data;
										   
}
									  
}
									  
extension extensionToJson on Object {  _toJson() => this;}