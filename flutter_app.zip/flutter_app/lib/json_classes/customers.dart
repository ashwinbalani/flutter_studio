
class Customers{
									  
bool  error;
num  errorCode;
List<Customers_items>  Items;

									  
Customers({this.error,
this.errorCode,
this.Items,});
									  

Customers.fromJson(Map<String, dynamic> json) {
											 
error = json['error'];
errorCode = json['error_code'];

if (json['_items'] != null) {
												  
Items = new List<Customers_items>();
												  
json['_items'].forEach((v) {
												  
Items.add(new Customers_items.fromJson(v));
												  
});
												  
}

											 
}
									  

										   
Map<String, dynamic> toJson()=> _toJson();
								   
Map<String, dynamic> _toJson() {
										   
final Map<String, dynamic> data = new Map<String, dynamic>();
										   
 data['error'] = this.error._toJson();
 data['error_code'] = this.errorCode._toJson();

if (this.Items != null) {
												
data['_items'] = this.Items.map((v) => v._toJson())?.toList();
												
}

										   
return data;
										   
}
									  
}
									  

class Customers_items{
									  
num  id;
String  name;
String  phone;
String  address;
String  profilePic;

									  
Customers_items({this.id,
this.name,
this.phone,
this.address,
this.profilePic,
});
									  

Customers_items.fromJson(Map<String, dynamic> json) {
											 
id = json['id'];
name = json['name'];
phone = json['phone'];
address = json['address'];
profilePic = json['profile_pic'];

											 
}
									  

										   
Map<String, dynamic> toJson()=> _toJson();
								   
Map<String, dynamic> _toJson() {
										   
final Map<String, dynamic> data = new Map<String, dynamic>();
										   
 data['id'] = this.id._toJson();
 data['name'] = this.name._toJson();
 data['phone'] = this.phone._toJson();
 data['address'] = this.address._toJson();
 data['profile_pic'] = this.profilePic._toJson();

										   
return data;
										   
}
									  
}
									  
extension extensionToJson on Object {  _toJson() => this;}