
class Purchase{
									  
bool  error;
num  errorCode;
List<Purchase_items>  Items;

									  
Purchase({this.error,
this.errorCode,
this.Items,});
									  

Purchase.fromJson(Map<String, dynamic> json) {
											 
error = json['error'];
errorCode = json['error_code'];

if (json['_items'] != null) {
												  
Items = new List<Purchase_items>();
												  
json['_items'].forEach((v) {
												  
Items.add(new Purchase_items.fromJson(v));
												  
});
												  
}

											 
}
									  

										   
Map<String, dynamic> toJson()=> _toJson();
								   
Map<String, dynamic> _toJson() {
										   
final Map<String, dynamic> data = new Map<String, dynamic>();
										   
 data['error'] = this.error._toJson();
 data['error_code'] = this.errorCode._toJson();

if (this.Items != null) {
												
data['_items'] = this.Items.map((v) => v._toJson())?.toList();
												
}

										   
return data;
										   
}
									  
}
									  

class Purchase_items{
									  
num  id;
num  customerId;
num  productId;
num  purchaseDate;

									  
Purchase_items({this.id,
this.customerId,
this.productId,
this.purchaseDate,
});
									  

Purchase_items.fromJson(Map<String, dynamic> json) {
											 
id = json['id'];
customerId = json['customer_id'];
productId = json['product_id'];
purchaseDate = json['purchase_date'];

											 
}
									  

										   
Map<String, dynamic> toJson()=> _toJson();
								   
Map<String, dynamic> _toJson() {
										   
final Map<String, dynamic> data = new Map<String, dynamic>();
										   
 data['id'] = this.id._toJson();
 data['customer_id'] = this.customerId._toJson();
 data['product_id'] = this.productId._toJson();
 data['purchase_date'] = this.purchaseDate._toJson();

										   
return data;
										   
}
									  
}
									  
extension extensionToJson on Object {  _toJson() => this;}