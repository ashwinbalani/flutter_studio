
class TblpurchaseTblproducts{
												
bool  error;
num  errorCode;
List<TblpurchaseTblproducts_items>  Items;

												
TblpurchaseTblproducts({this.error,
this.errorCode,
this.Items,});
												

TblpurchaseTblproducts.fromJson(Map<String, dynamic> json) {
													 
error = json['error'];
errorCode = json['error_code'];

if (json['_items'] != null) {
															
Items = new List<TblpurchaseTblproducts_items>();
															
json['_items'].forEach((v) {
															
Items.add(new TblpurchaseTblproducts_items.fromJson(v));
															
});
															
}

													 
}
												

													 
Map<String, dynamic> toJson()=> _toJson();
											 
Map<String, dynamic> _toJson() {
													 
final Map<String, dynamic> data = new Map<String, dynamic>();
													 
 data['error'] = this.error._toJson();
 data['error_code'] = this.errorCode._toJson();

if (this.Items != null) {
														
data['_items'] = this.Items.map((v) => v._toJson())?.toList();
														
}

													 
return data;
													 
}
												
}
												

class TblpurchaseTblproducts_items{
												
num  id;
num  customerId;
num  productId;
num  purchaseDate;
num  tblproductsProductIdId;
String  tblproductsProductIdName;
String  tblproductsProductIdWeight;
String  tblproductsProductIdDescription;
num  tblproductsProductIdPrice;
String  tblproductsProductIdImageUrl;

												
TblpurchaseTblproducts_items({this.id,
this.customerId,
this.productId,
this.purchaseDate,
this.tblproductsProductIdId,
this.tblproductsProductIdName,
this.tblproductsProductIdWeight,
this.tblproductsProductIdDescription,
this.tblproductsProductIdPrice,
this.tblproductsProductIdImageUrl,
});
												

TblpurchaseTblproducts_items.fromJson(Map<String, dynamic> json) {
													 
id = json['id'];
customerId = json['customer_id'];
productId = json['product_id'];
purchaseDate = json['purchase_date'];
tblproductsProductIdId = json['tblproducts__product_id_id'];
tblproductsProductIdName = json['tblproducts__product_id_name'];
tblproductsProductIdWeight = json['tblproducts__product_id_weight'];
tblproductsProductIdDescription = json['tblproducts__product_id_description'];
tblproductsProductIdPrice = json['tblproducts__product_id_price'];
tblproductsProductIdImageUrl = json['tblproducts__product_id_image_url'];

													 
}
												

													 
Map<String, dynamic> toJson()=> _toJson();
											 
Map<String, dynamic> _toJson() {
													 
final Map<String, dynamic> data = new Map<String, dynamic>();
													 
 data['id'] = this.id._toJson();
 data['customer_id'] = this.customerId._toJson();
 data['product_id'] = this.productId._toJson();
 data['purchase_date'] = this.purchaseDate._toJson();
 data['tblproducts__product_id_id'] = this.tblproductsProductIdId._toJson();
 data['tblproducts__product_id_name'] = this.tblproductsProductIdName._toJson();
 data['tblproducts__product_id_weight'] = this.tblproductsProductIdWeight._toJson();
 data['tblproducts__product_id_description'] = this.tblproductsProductIdDescription._toJson();
 data['tblproducts__product_id_price'] = this.tblproductsProductIdPrice._toJson();
 data['tblproducts__product_id_image_url'] = this.tblproductsProductIdImageUrl._toJson();

													 
return data;
													 
}
												
}
												
extension extensionToJson on Object {  _toJson() => this;}