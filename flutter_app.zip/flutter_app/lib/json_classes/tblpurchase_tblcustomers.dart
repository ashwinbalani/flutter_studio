
class TblpurchaseTblcustomers{
												
bool  error;
num  errorCode;
List<TblpurchaseTblcustomers_items>  Items;

												
TblpurchaseTblcustomers({this.error,
this.errorCode,
this.Items,});
												

TblpurchaseTblcustomers.fromJson(Map<String, dynamic> json) {
													 
error = json['error'];
errorCode = json['error_code'];

if (json['_items'] != null) {
															
Items = new List<TblpurchaseTblcustomers_items>();
															
json['_items'].forEach((v) {
															
Items.add(new TblpurchaseTblcustomers_items.fromJson(v));
															
});
															
}

													 
}
												

													 
Map<String, dynamic> toJson()=> _toJson();
											 
Map<String, dynamic> _toJson() {
													 
final Map<String, dynamic> data = new Map<String, dynamic>();
													 
 data['error'] = this.error._toJson();
 data['error_code'] = this.errorCode._toJson();

if (this.Items != null) {
														
data['_items'] = this.Items.map((v) => v._toJson())?.toList();
														
}

													 
return data;
													 
}
												
}
												

class TblpurchaseTblcustomers_items{
												
num  id;
num  customerId;
num  productId;
num  purchaseDate;
num  tblcustomersCustomerIdId;
String  tblcustomersCustomerIdName;
String  tblcustomersCustomerIdPhone;
String  tblcustomersCustomerIdAddress;
String  tblcustomersCustomerIdProfilePic;

												
TblpurchaseTblcustomers_items({this.id,
this.customerId,
this.productId,
this.purchaseDate,
this.tblcustomersCustomerIdId,
this.tblcustomersCustomerIdName,
this.tblcustomersCustomerIdPhone,
this.tblcustomersCustomerIdAddress,
this.tblcustomersCustomerIdProfilePic,
});
												

TblpurchaseTblcustomers_items.fromJson(Map<String, dynamic> json) {
													 
id = json['id'];
customerId = json['customer_id'];
productId = json['product_id'];
purchaseDate = json['purchase_date'];
tblcustomersCustomerIdId = json['tblcustomers__customer_id_id'];
tblcustomersCustomerIdName = json['tblcustomers__customer_id_name'];
tblcustomersCustomerIdPhone = json['tblcustomers__customer_id_phone'];
tblcustomersCustomerIdAddress = json['tblcustomers__customer_id_address'];
tblcustomersCustomerIdProfilePic = json['tblcustomers__customer_id_profile_pic'];

													 
}
												

													 
Map<String, dynamic> toJson()=> _toJson();
											 
Map<String, dynamic> _toJson() {
													 
final Map<String, dynamic> data = new Map<String, dynamic>();
													 
 data['id'] = this.id._toJson();
 data['customer_id'] = this.customerId._toJson();
 data['product_id'] = this.productId._toJson();
 data['purchase_date'] = this.purchaseDate._toJson();
 data['tblcustomers__customer_id_id'] = this.tblcustomersCustomerIdId._toJson();
 data['tblcustomers__customer_id_name'] = this.tblcustomersCustomerIdName._toJson();
 data['tblcustomers__customer_id_phone'] = this.tblcustomersCustomerIdPhone._toJson();
 data['tblcustomers__customer_id_address'] = this.tblcustomersCustomerIdAddress._toJson();
 data['tblcustomers__customer_id_profile_pic'] = this.tblcustomersCustomerIdProfilePic._toJson();

													 
return data;
													 
}
												
}
												
extension extensionToJson on Object {  _toJson() => this;}