import 'package:flutter/material.dart';
import 'package:flutterapp/my_awesome_dashboard/simple_values.dart';
import 'package:flutterapp/my_awesome_screen/singlepage_with_slider.dart';

import 'screen_customers.dart';
import 'screen_products.dart';
import 'screen_purchase.dart';
import 'uidata.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Speedy Code',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: UIData.primaryColor,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Speedy Code: Operations'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
            child: Column(
          children: <Widget>[
            Text("Select a screen to launch", style: TextStyle(fontSize: 30)),
            //showButton("Screen Users", (){Navigator.of(context).push(MaterialPageRoute(builder: (context) => ScreenUsers()));}),
            showButton('Screen Customers', () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => ScreenCustomers()));
            }),
            showButton('Screen Products', () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => ScreenProducts()));
            }),
            showButton('Screen Purchase', () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => ScreenPurchase()));
            }),
            showButton('My Awesome E Commerce Page', () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => SinglePageWithSlider()));
            }),
            showButton('My Awesome Dashboard', () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => SimpleValues()));
            }),
          ],
        )),
      ),
    );
  }

  Widget showButton(String text, Function function) {
    return Align(
      alignment: Alignment.center,
      child: Padding(
        padding: EdgeInsets.all(10),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: MaterialButton(
              color: UIData.primaryColor,
              minWidth: MediaQuery.of(context).size.width,
              child: new Text(text,
                  style: new TextStyle(fontSize: 16.0, color: Colors.white)),
              onPressed: () {
                function();
              }),
        ),
      ),
    );
  }
}
