import 'uidata.dart';

import 'package:flutter/material.dart';

//const Color primaryColor = Color(0xff1E1C61);
//const Color secondaryColor = Color(0x110000F9);
const Color backgroundColor = Colors.white24;

const String loaderImagePath = "assets/placeholder.jpg";
const Color primaryColor = UIData.primaryColor;
const Color secondaryColor = UIData.secondaryColor;
