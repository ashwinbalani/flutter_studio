package com.flutterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
